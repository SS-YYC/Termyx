def run():
    while True:
        count = 0
        while True:
            tc_value = input("Hit enter to increase the count by 1. To end the counter, type 'stop': ")
            if tc_value.strip().lower() == "stop":
                break
            count += 1
            print(f"The count is currently at {count}.")

        print(f"Final count: {count}")
        again = input("Do this again? (y/n):\n> ").lower().strip()
        if again != "y":
            break
