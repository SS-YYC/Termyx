def run():
    while True:
        try:
            num1 = float(input("Please enter your first number:\n> "))
            operation = input("Please enter the operation you would like to perform (+, -, *, /, **)\n> ")
            num2 = float(input("Please enter your second number:\n> "))
        except ValueError:
            print("Numbers only. Try again.")
            continue

        if operation.strip() == "+":
            print("Your answer is", num1 + num2)
        elif operation.strip() == "-":
            print("Your answer is", num1 - num2)
        elif operation.strip() == "*":
            print("Your answer is", num1 * num2)
        elif operation.strip() == "/":
            if num2 == 0:
                print("You can't divide by zero.")
            else:
                print("Your answer is", num1 / num2)
        elif operation.strip() == "**":
            if num1 == 0 and num2 <= 0:
                print("0 cannot be raised to zero or a negative power.")
            elif num1 < 0 and not num2.is_integer():
                print("Negative numbers cannot be raised to fractional powers.")
            elif num1 == 0 and num2 > 0:
                print("Your answer is 0.")
            else:
                print("Your answer is", num1 ** num2)
            
        else:
            print("Invalid operation.")
            continue

        again = input("Do this again? (y/n):\n> ").lower().strip()
        if again != "y":
            break