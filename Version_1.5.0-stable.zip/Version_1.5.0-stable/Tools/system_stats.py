import time
import threading
import psutil

monitor_running = False


def _monitor_thread():
    global monitor_running

    psutil.cpu_percent(None)
    time.sleep(0.5)

    while monitor_running:
        cpu = psutil.cpu_percent(None)
        ram = psutil.virtual_memory().percent
        print(f"\rCPU: {cpu}% | RAM: {ram}%   ", end="", flush=True)
        time.sleep(0.5)


def run():
    global monitor_running

    while True:
        monitor_running = True
        print("\nType 'stop' to exit the system monitor.\n")

        thread = threading.Thread(target=_monitor_thread, daemon=True)
        thread.start()

        while True:
            sys_cmd = input("> ").strip().lower()

            if sys_cmd == "stop":
                monitor_running = False
                thread.join()
                print("\nSystem monitor stopped.")
                break
            else:
                print("Unknown command. Type 'stop' to exit.")

        again = input("Do this again? (y/n):\n> ").strip().lower()
        if again != "y":
            break
