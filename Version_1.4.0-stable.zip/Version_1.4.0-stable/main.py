import sys
from Tools import timer, stopwatch, calculator, tally, system_stats, rng

changelog = ("""
\n
Changelog:

Added in Version 1.4.0:

• Termyx has been modularized! Each tool now lives in its own file under the tools/ folder.
• The calculator app has been modified with a more natural input sequence.
• The ability to calculate exponents has been added to the calculator using the ** operator.
• A new interval mode has been added to the timer app, allowing users to count down from a starting number to an end number with a custom interval and delay. 
    • This replaces the counter app which is no longer available.
    • I will gauge usage of the interval timer and change it back to a counter if there is not much interest in the new feature, or remove it entirely.
• A new help command has been added to the main directory, allowing users to view helplinks and a slimmed UX guide.
• A new random number generator tool has been added, allowing users to generate a random number between two specified limits.
• Minor changes to the tally counter's interface.
• The system stats tool has been optimized to update every 0.5 seconds instead of every second, and the interface has been slightly modified to be more compact and easier to read.
             
And the following bug fixes:
• Various small bugs and typos have been fixed across the codebase.
• Minor optimization improvements have been made across the entire app.

In the Works:

• A new unit converter tool, which will allow users to convert between various units of measurement such as length, mass, and temperature. 
• A dice roller tool, which will allow users to roll various types of dice with customizable numbers of sides and rolls.
• A pomodoro timer tool, which will allow users to set work and break intervals to help with productivity and time management.
• More complex calculator functions, such as percentages and square roots.             
""")

helplinks = ("""
Available Tools:
             
• Stopwatch – Track elapsed time with start, stop, and reset commands.
• Timer – Set a countdown or interval timer in seconds, perfect for short tasks or exercises.
• Calculator – Perform basic arithmetic operations (+, -, *, /, **) quickly.
• Tally Counter – Keep track of counts by pressing enter to increment the total.
• System Stats – Track your CPU and RAM usage, updated to the nearest second.  
• Random Number Generator – Generate a random number between two specified limits.           



Helplinks:
Join the Discord Server -> https://discord.gg/eJqdyjRv

Check out the GitHub -> https://github.com/SS-YYC/Termyx
""")

break_msg = "\nApp terminated successfully. Goodbye!"

directory_disp = (
    "timer (tmr)",
    "stopwatch (sw)",
    "calculator (calc)",
    "tally counter (tly)",
    "system stats (sys)",
    "random number generator (rng)"
)

valid_commands = (
    "timer", "tmr",
    "stopwatch", "sw",
    "calculator", "calc",
    "tally counter", "tly",
    "system stats", "sys",
    "random number generator", "rng"
)

try:
    print(r"""
 _____                              
|_   _|__ _ __ _ __ ___  _   ___  __
  | |/ _ \ '__| '_ ` _ \| | | \ \/ /
  | |  __/ |  | | | | | | |_| |>  < 
  |_|\___|_|  |_| |_| |_|\__, /_/\_\  v.1.4.0
                         |___/                                                                                                
Termyx - made by SS-YYC. Licensed under GPL-3.0. Feel free to use and modify this code at your own leisure.                                   
                 """)

    print("Welcome to Termyx!")
    print("Please follow the instructions below to use the app! To quit at any time, hit CTRL + C on your keyboard.")

    cl = input("Hit Enter to proceed. To view the changelog, type 'changelog' or 'cl'. For help and support, type 'help' or 'h'.\n> ")
    if cl.lower().strip() in ("changelog", "cl"):
        print(changelog)
    if cl.lower().strip() in ("help", "h"):
        print(helplinks)

    while True:
        # Tool selection
        while True:
            try:
                choice = input(f"\nPlease select the tool you'll be using today out of these options: {', '.join(directory_disp)}.\n> ")
                if choice.lower().strip() in valid_commands:
                    break
                else:
                    print("Invalid entry.")
            except ValueError:
                print("One of your inputs is not recognized by the system.")

        # Route to the correct tool
        if choice.lower().strip() in ("timer", "tmr"):
            timer.run()
        elif choice.lower().strip() in ("stopwatch", "sw"):
            stopwatch.run()
        elif choice.lower().strip() in ("calculator", "calc"):
            calculator.run()
        elif choice.lower().strip() in ("tally counter", "tly"):
            tally.run()
        elif choice.lower().strip() in ("system stats", "sys"):
            system_stats.run()
        elif choice.lower().strip() in ("random number generator", "rng"):
            rng.run()
        # Return to directory?
        directoryReturn = input("Run the directory again? (y/n):\n> ")
        if directoryReturn.strip().lower() in ("y", "yes"):
            continue
        else:
            print("Thanks for using the app! To report any bugs, join the Discord or report an issue on GitHub.")
            break

except (KeyboardInterrupt, EOFError):
    print(break_msg)
    sys.exit()
